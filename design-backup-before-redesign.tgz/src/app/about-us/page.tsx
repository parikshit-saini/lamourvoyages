import type { Metadata } from "next";
import Image from "next/image";
import CtaBand from "@/components/CtaBand/CtaBand";
import Icon from "@/components/Icon/Icon";
import PageHero from "@/components/PageHero/PageHero";
import Partners from "@/components/Partners/Partners";
import SectionHeading from "@/components/SectionHeading/SectionHeading";
import WhyBook from "@/components/WhyBook/WhyBook";
import { images, offices } from "@/data/site";
import styles from "@/styles/pages.module.scss";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "L'amour Voyages is a worldwide customized travel and hospitality company with offices in the USA, UK, India and Canada.",
  alternates: { canonical: "/about-us" },
};

const values = [
  { icon: "bolt", title: "Proactive", text: "We anticipate needs before they become problems — from flight changes to late check-ins." },
  { icon: "task_alt", title: "Effective", text: "Clear proposals, fast confirmations and on-ground teams who get things done." },
  { icon: "lightbulb", title: "Innovative", text: "Fresh routes, new hotels and experiences that make each journey feel personal." },
  { icon: "speed", title: "Efficient", text: "Streamlined operations across four offices keep costs transparent and service fast." },
];

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="Our Story"
        title="About L'amour Voyages"
        subtitle="A worldwide unique customized travel and hospitality service — proactive, effective, innovative and efficient."
        image={images.eastAmerica}
        crumbs={[{ label: "About Us" }]}
      />

      <section className={styles.section}>
        <div className={`container ${styles.split}`}>
          <div>
            <SectionHeading align="left" eyebrow="Who we are" title="Travel designed around you" />
            <p className={styles.lead}>
              L&apos;amour Voyages plans tailor-made journeys for private travellers, families, corporate
              delegations and travel-trade partners. Every itinerary is built from scratch around your dates,
              interests and budget.
            </p>
            <p className={styles.lead}>
              With teams in the USA, UK, India and Canada, we combine local destination knowledge with
              round-the-clock support — so there is always someone awake and available while you travel.
            </p>
            <div className={styles.stats}>
              <div className={styles.stat}><strong>4</strong><span>Global offices</span></div>
              <div className={styles.stat}><strong>24/7</strong><span>Concierge support</span></div>
              <div className={styles.stat}><strong>B2B</strong><span>&amp; B2C delivery</span></div>
              <div className={styles.stat}><strong>100%</strong><span>Customized pacing</span></div>
            </div>
          </div>
          <div className={styles.imageFrame}>
            <Image src={images.newYork} alt="New York skyline" fill sizes="(min-width: 1024px) 50vw, 100vw" />
          </div>
        </div>
      </section>

      <section className={styles.sectionWhite}>
        <div className="container">
          <SectionHeading eyebrow="Our approach" title="What Guides Every Journey" />
          <div className={styles.cards4}>
            {values.map((v) => (
              <div key={v.title} className={styles.card}>
                <span className={styles.icon}><Icon name={v.icon} size={24} /></span>
                <h3>{v.title}</h3>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
          <WhyBook />
        </div>
      </section>

      <section className={styles.sectionTint}>
        <div className="container">
          <SectionHeading eyebrow="Leadership" title="The People Behind Your Trip" />
          <div className={styles.team}>
            <div className={styles.person}>
              <span className={styles.avatar}>SG</span>
              <div>
                <h3>Shobhit Goyal</h3>
                <small>Senior Destination Director • Americas Desk</small>
                <p>Leads Lamour Voyages USA LLC and our trade partnerships across Europe and the Americas.</p>
              </div>
            </div>
            <div className={styles.person}>
              <span className={styles.avatar}>TG</span>
              <div>
                <h3>Tushar Goyal</h3>
                <small>Senior Destination Director • Americas Desk</small>
                <p>Known by our partners for coordinating guests at any hour with clockwork precision.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.section}>
        <div className="container">
          <SectionHeading eyebrow="Where we are" title="Our Global Offices" />
          <div className={styles.cards4}>
            {offices.map((o) => (
              <div key={o.country} className={styles.card}>
                <span className={styles.iconAzure}><Icon name="location_on" size={24} /></span>
                <h3>{o.country}</h3>
                <p>{o.address}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaBand />
      <Partners />
    </>
  );
}
