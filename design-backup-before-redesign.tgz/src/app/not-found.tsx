import Link from "next/link";
import PageHero from "@/components/PageHero/PageHero";

export default function NotFound() {
  return (
    <>
      <PageHero
        eyebrow="404"
        title="This page has wandered off"
        subtitle="The page you're looking for doesn't exist or has moved."
      />
      <div className="container" style={{ padding: "4rem 0", display: "flex", gap: 12, flexWrap: "wrap" }}>
        <Link href="/" className="btn btn--navy">Back to Home</Link>
        <Link href="/contact-us" className="btn btn--gold">Contact Us</Link>
      </div>
    </>
  );
}
