import Link from "next/link";
import Icon from "@/components/Icon/Icon";
import Hero from "@/components/Home/Hero";
import Partners from "@/components/Partners/Partners";
import Planner from "@/components/Planner/Planner";
import SectionHeading from "@/components/SectionHeading/SectionHeading";
import Testimonials from "@/components/Testimonials/Testimonials";
import TourCard from "@/components/Tours/TourCard";
import TourPortfolio from "@/components/Tours/TourPortfolio";
import WhyBook from "@/components/WhyBook/WhyBook";
import { tours } from "@/data/site";
import styles from "./page.module.scss";

const INTRO =
  "Lamour Voyages, a worldwide unique customized travel and hospitality service. Our approach is proactive, effective, innovative, and efficient.";

export default function HomePage() {
  const featured = tours.filter((t) => t.featured);

  return (
    <>
      <Hero />

      {/* Signature selection */}
      <section className={styles.featured}>
        <div className="container">
          <div className={styles.featuredHead}>
            <SectionHeading align="left" eyebrow="Signature Selection" title="Best of America" text={INTRO} />
            <Link href="#all-packages" className="btn btn--light btn--pill">
              Explore All {tours.length}+ Expeditions
              <Icon name="arrow_forward" size={16} />
            </Link>
          </div>
          <div className={styles.grid}>
            {featured.map((tour) => (
              <TourCard key={tour.id} tour={tour} showFavorite />
            ))}
          </div>
        </div>
      </section>

      {/* Full portfolio */}
      <section className={styles.portfolio} id="all-packages">
        <div className="container">
          <SectionHeading
            eyebrow="Complete America Portfolio"
            title="America Best Tour Packages"
            text={`${INTRO} We have tailor-made and customized tour packages.`}
          />
          <TourPortfolio />
          <WhyBook />
        </div>
      </section>

      <Planner />
      <Testimonials />
      <Partners />
    </>
  );
}
