import type { Metadata } from "next";
import Image from "next/image";
import CtaBand from "@/components/CtaBand/CtaBand";
import Icon from "@/components/Icon/Icon";
import PageHero from "@/components/PageHero/PageHero";
import SectionHeading from "@/components/SectionHeading/SectionHeading";
import { contact, images } from "@/data/site";
import styles from "@/styles/pages.module.scss";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Tailor-made FIT holidays, group tours, MICE, hotel reservations, transfers, guided sightseeing and B2B ground handling across the Americas.",
  alternates: { canonical: "/services" },
};

const services = [
  {
    icon: "person",
    title: "FIT Holidays",
    text: "Fully independent, tailor-made trips for couples, families and solo travellers.",
    points: ["Custom routing", "Hand-picked hotels", "Private or seat-in-coach tours"],
  },
  {
    icon: "groups",
    title: "Group Tours",
    text: "Smooth logistics for leisure groups, student tours and special-interest travel.",
    points: ["Group allocations", "Tour managers", "Dedicated coaches"],
  },
  {
    icon: "business_center",
    title: "MICE & Corporate",
    text: "Meetings, incentives, conferences and delegations handled end-to-end.",
    points: ["Venue sourcing", "Incentive programs", "On-site coordination"],
  },
  {
    icon: "hotel",
    title: "Hotel Reservations",
    text: "Preferred rates and upgrades with leading hotel chains and boutique properties.",
    points: ["4★ & 5★ hotels", "Resort villas", "Early check-in requests"],
  },
  {
    icon: "airport_shuttle",
    title: "Transfers & Chauffeurs",
    text: "Airport pick-ups, inter-city transfers and chauffeur-driven vehicles.",
    points: ["Meet & greet", "Sedans to coaches", "24/7 dispatch"],
  },
  {
    icon: "tour",
    title: "Guided Sightseeing",
    text: "Licensed local guides and VIP access to the best attractions.",
    points: ["Private guides", "Skip-the-line tickets", "Language options"],
  },
  {
    icon: "flight",
    title: "Private Aviation & Charters",
    text: "Helicopter flights and private jet charters for time-critical or special trips.",
    points: ["Helicopter tours", "Jet charters", "Scenic flights"],
  },
  {
    icon: "sailing",
    title: "Superyacht Escapes",
    text: "Day charters and multi-day yacht experiences in Miami and beyond.",
    points: ["Crewed charters", "Sunset cruises", "Celebrations aboard"],
  },
  {
    icon: "favorite",
    title: "Honeymoons & Celebrations",
    text: "Romantic stays, surprises and special occasions planned to perfection.",
    points: ["Suite upgrades", "Private dinners", "Personal touches"],
  },
];

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="What we do"
        title="Our Services"
        subtitle="From a single hotel booking to a multi-country group program — one team, available 24/7."
        image={images.westCoast}
        crumbs={[{ label: "Services" }]}
      />

      <section className={styles.section}>
        <div className="container">
          <SectionHeading
            eyebrow="End-to-end travel"
            title="Everything Your Journey Needs"
            text="Choose a single service or let us handle the complete trip — every element is tailored to you."
          />
          <div className={styles.cards}>
            {services.map((s, i) => (
              <div key={s.title} className={styles.card}>
                <span className={i % 2 ? styles.iconAzure : styles.icon}>
                  <Icon name={s.icon} size={24} />
                </span>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
                <ul>
                  {s.points.map((p) => (
                    <li key={p}>
                      <Icon name="check" size={16} /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={styles.sectionWhite} id="b2b">
        <div className={`container ${styles.split}`}>
          <div className={styles.imageFrame}>
            <Image src={images.brazilArgentina} alt="" fill sizes="(min-width: 1024px) 50vw, 100vw" />
          </div>
          <div>
            <SectionHeading align="left" eyebrow="Partner with us" title="B2B Trade Alliances" />
            <p className={styles.lead}>
              We provide wholesale ground handling, group allocations, and customized white-label luxury
              itineraries for certified travel advisors globally.
            </p>
            <p className={styles.lead}>
              Tour operators across India, Asia and Europe rely on our Americas desk for fast quotes, reliable
              suppliers and support at any hour.
            </p>
            <a href={`tel:${contact.usaTel}`} className="btn btn--azure">
              <Icon name="support_agent" size={18} /> Speak to Trade Desk
            </a>
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
