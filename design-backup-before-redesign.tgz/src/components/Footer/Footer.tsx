import Link from "next/link";
import Icon from "@/components/Icon/Icon";
import { affiliations, contact, offices, social } from "@/data/site";
import NewsletterForm from "./NewsletterForm";
import styles from "./Footer.module.scss";

const portfolios = [
  { label: "North America Luxury Escapes", href: "/north-america" },
  { label: "South America Expeditions", href: "/south-america" },
  { label: "Canadian Wilderness Lodges", href: "/canada" },
  { label: "Trending Metropolises (NY, LA, Miami)", href: "/trending-destination" },
  { label: "Private Aviation & Charters", href: "/services" },
  { label: "Superyacht Escapes", href: "/services" },
];

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className={styles.footer}>
      <div className="container">
        {/* Newsletter */}
        <div className={styles.newsletter}>
          <div className={styles.newsletterText}>
            <span className={styles.eyebrow}>Private Dispatch</span>
            <h4>Receive Curated Itineraries &amp; Secret Escapes</h4>
            <p>
              Join our privileged circle of global travelers for seasonal private charter availability and
              premier villa debuts.
            </p>
          </div>
          <NewsletterForm />
        </div>

        <div className={styles.grid}>
          {/* Brand */}
          <div className={styles.brandCol}>
            <div className={styles.brand}>
              <span className={styles.brandIcon}>
                <Icon name="flight_takeoff" />
              </span>
              <span>L&apos;amour Voyages</span>
            </div>
            <p className={styles.about}>
              Architecting peerless bespoke expeditions, VIP cultural journeys, and five-star luxury retreats
              across the Americas. Tailored with seamless white-glove precision and 24/7 dedicated private
              concierge attendance.
            </p>
            <div className={styles.care}>
              <strong>Global Direct Care:</strong>
              <a href={`tel:${contact.usaTel}`}>USA Hotline: {contact.usaPhone}</a>
              <a href={`tel:${contact.indiaTel}`}>India Hotline: {contact.indiaPhone}</a>
              <a href={`mailto:${contact.conciergeEmail}`}>Email: {contact.conciergeEmail}</a>
            </div>
            <div className={styles.social}>
              {social.map((s) => (
                <a key={s.label} href={s.href} aria-label={s.label} target="_blank" rel="noopener noreferrer">
                  <Icon name={s.icon} size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Offices */}
          <div className={styles.col}>
            <h5>Our Global Offices</h5>
            <div className={styles.offices}>
              {offices.map((o) => (
                <div key={o.country}>
                  <strong>{o.country}</strong>
                  <span>{o.address}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Portfolios */}
          <div className={styles.col}>
            <h5>Curated Portfolios</h5>
            <ul className={styles.links}>
              {portfolios.map((p) => (
                <li key={p.label}>
                  <Link href={p.href}>{p.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Affiliations */}
          <div className={styles.col}>
            <h5>Affiliations &amp; Trust</h5>
            <div className={styles.affiliations}>
              {affiliations.map((a) => (
                <div key={a.title} className={styles.affiliation}>
                  <Icon name={a.icon} size={22} className={a.tone === "azure" ? styles.azure : styles.gold} />
                  <div>
                    <div className={styles.affTitle}>{a.title}</div>
                    <div className={styles.affSub}>{a.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className={styles.bottom}>
          <div className={styles.legal}>
            <span>© {year} L&apos;amour Voyages Inc. All rights reserved.</span>
            <span>CIN: U63040UP2019PTC118544</span>
            <span>GSTIN: 09AAACL1943D1Z0</span>
          </div>
          <div className={styles.bottomLinks}>
            <Link href="/privacy-policy">Privacy Policy</Link>
            <Link href="/privacy-policy#terms">Terms of Service</Link>
            <Link href="/contact-us">Luxury Travel Advisory</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
