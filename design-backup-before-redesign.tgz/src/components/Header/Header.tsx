"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Icon from "@/components/Icon/Icon";
import { LOGO_URL, contact, mainNav, type NavItem } from "@/data/site";
import styles from "./Header.module.scss";

function isActive(pathname: string, item: NavItem) {
  if (item.href === "/") return pathname === "/";
  if (item.href.startsWith("/#")) return false;
  if (pathname === item.href) return true;
  return item.children?.some((c) => c.href === pathname) ?? false;
}

export default function Header() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  // Close the mobile menu on navigation
  useEffect(() => setMenuOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  return (
    <header className={styles.header}>
      {/* Top utility bar */}
      <div className={styles.topBar}>
        <div className={styles.topInner}>
          <div className={styles.topLeft}>
            <span className={styles.concierge}>
              <Icon name="support_agent" size={14} /> 24/7 Global Concierge:
            </span>
            <a href={`tel:${contact.usaTel}`}>USA {contact.usaPhone}</a>
            <span className={styles.divider}>|</span>
            <a href={`tel:${contact.indiaTel}`} className={styles.hideXs}>
              IND {contact.indiaPhone}
            </a>
          </div>
          <div className={styles.topRight}>
            <span className={styles.muted}>Offices:</span>
            <span className={styles.offices}>USA • UK • India • Canada</span>
            <span className={styles.accredited}>
              <Icon name="verified" size={12} /> ATOL &amp; IATA Accredited
            </span>
          </div>
        </div>
      </div>

      {/* Main bar */}
      <div className={styles.mainBar}>
        <Link href="/" className={styles.brand} aria-label="L'amour Voyages home">
          <Image src={LOGO_URL} alt="" width={120} height={32} className={styles.logo} priority unoptimized />
          <span className={styles.brandText}>
            <span className={styles.brandName}>L&apos;amour Voyages</span>
            <span className={styles.brandTag}>Luxury Bespoke Expeditions</span>
          </span>
        </Link>

        <nav className={styles.nav} aria-label="Main">
          {mainNav.map((item) =>
            item.children ? (
              <div key={item.href} className={styles.dropdown}>
                <Link
                  href={item.href}
                  className={`${styles.navLink} ${isActive(pathname, item) ? styles.active : ""}`}
                  aria-haspopup="true"
                >
                  {item.label}
                  <span className={styles.trendPill}>NY, LA, Miami, Orlando, Boston</span>
                </Link>
                <div className={styles.menu} role="menu">
                  {item.children.map((child) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      role="menuitem"
                      className={`${styles.menuItem} ${pathname === child.href ? styles.active : ""}`}
                    >
                      <Icon name="location_on" size={16} />
                      {child.label}
                    </Link>
                  ))}
                </div>
              </div>
            ) : (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive(pathname, item) ? "page" : undefined}
                className={`${styles.navLink} ${isActive(pathname, item) ? styles.active : ""}`}
              >
                {item.label}
              </Link>
            ),
          )}
        </nav>

        <div className={styles.actions}>
          <Link href="/contact-us#planner" className={`btn btn--gold btn--pill ${styles.cta}`}>
            <Icon name="travel_explore" size={16} />
            Inquire Now / Plan Your Trip
          </Link>
          <button
            type="button"
            className={styles.burger}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((v) => !v)}
          >
            <Icon name={menuOpen ? "close" : "menu"} size={24} />
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      <div className={`${styles.drawer} ${menuOpen ? styles.drawerOpen : ""}`}>
        <nav aria-label="Mobile">
          {mainNav.map((item) => (
            <div key={item.href}>
              <Link
                href={item.href}
                className={`${styles.drawerLink} ${isActive(pathname, item) ? styles.active : ""}`}
              >
                {item.label}
              </Link>
              {item.children && (
                <div className={styles.drawerSub}>
                  {item.children.map((child) => (
                    <Link key={child.href} href={child.href} className={styles.drawerSubLink}>
                      {child.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
          <Link href="/contact-us#planner" className="btn btn--gold" style={{ marginTop: 16, width: "100%" }}>
            <Icon name="travel_explore" size={16} /> Plan Your Trip
          </Link>
        </nav>
      </div>
    </header>
  );
}
