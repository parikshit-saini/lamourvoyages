"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Icon from "@/components/Icon/Icon";
import { images } from "@/data/site";
import styles from "./Hero.module.scss";

const tabs = [
  { id: "bespoke", label: "Bespoke Tours", icon: "auto_awesome", tone: "gold" },
  { id: "fit", label: "FIT Query (Individual)", icon: "person", tone: "azure" },
  { id: "group", label: "Group Query", icon: "groups", tone: "secondary" },
  { id: "finder", label: "Destination Finder", icon: "map", tone: "gold" },
] as const;

type TabId = (typeof tabs)[number]["id"];

const destinationOptions = [
  { value: "", label: "All Americas & Global" },
  { value: "/north-america", label: "North America (USA East & West)" },
  { value: "/south-america", label: "South America (Brazil & Argentina)" },
  { value: "/new-york", label: "New York City & East Coast" },
  { value: "/los-angeles", label: "West Coast & Grand Canyon" },
  { value: "/canada", label: "Canada (Niagara, Toronto, Banff)" },
  { value: "/trending-destination", label: "Trending: Miami, Orlando, Boston" },
];

const badges = [
  { icon: "verified", label: "24/7 Dedicated Concierge", tone: "azure" },
  { icon: "public", label: "4 Global Offices (USA, UK, India, Canada)", tone: "gold" },
  { icon: "design_services", label: "Custom Tailor-Made Itineraries", tone: "azure" },
  { icon: "handshake", label: "Trusted by Leading Travel Operators", tone: "gold" },
];

export default function Hero() {
  const router = useRouter();
  const [tab, setTab] = useState<TabId>("bespoke");
  const [destination, setDestination] = useState("");
  const [rooms, setRooms] = useState("1");
  const [travelers, setTravelers] = useState("2");

  function selectTab(id: TabId) {
    setTab(id);
    if (id === "fit") {
      setRooms("1");
      setTravelers("2");
    } else if (id === "group") {
      setRooms("10+");
      setTravelers("12+");
    }
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (destination) {
      router.push(destination);
    } else {
      document.getElementById("planner")?.scrollIntoView({ behavior: "smooth" });
    }
  }

  return (
    <section className={styles.hero}>
      <div className={styles.bg} aria-hidden="true">
        <Image src={images.hero} alt="" fill priority sizes="100vw" className={styles.bgImage} />
        <div className={styles.gradient} />
        <div className={styles.glowAzure} />
        <div className={styles.glowGold} />
      </div>

      <div className={styles.inner}>
        <div className={styles.copy}>
          <div className={styles.kicker}>
            <Icon name="hotel_class" size={14} />
            <span>Bespoke Luxury Expeditions across the Americas &amp; Worldwide</span>
          </div>
          <h1 className={styles.title}>Extraordinary Journeys Across the Americas &amp; Beyond</h1>
          <p className={styles.lead}>
            Lamour Voyages, a worldwide unique customized travel and hospitality service. Our approach is
            proactive, effective, innovative, and efficient.
          </p>

          <ul className={styles.badges}>
            {badges.map((b) => (
              <li key={b.label}>
                <Icon name={b.icon} size={18} className={styles[b.tone]} />
                <span>{b.label}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Quick query */}
        <div className={styles.search}>
          <div className={styles.tabs} role="tablist">
            {tabs.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={tab === t.id}
                className={`${styles.tab} ${tab === t.id ? styles.tabActive : ""}`}
                onClick={() => selectTab(t.id)}
              >
                <Icon name={t.icon} size={18} className={styles[t.tone]} />
                {t.label}
              </button>
            ))}
          </div>

          <form className={styles.form} onSubmit={onSubmit}>
            <label className={styles.field}>
              <span className={styles.label}>
                <Icon name="location_on" size={14} className={styles.gold} /> Destination
              </span>
              <span className={styles.selectWrap}>
                <select value={destination} onChange={(e) => setDestination(e.target.value)}>
                  {destinationOptions.map((o) => (
                    <option key={o.label} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <Icon name="expand_more" size={18} />
              </span>
            </label>

            <label className={styles.field}>
              <span className={styles.label}>
                <Icon name="calendar_month" size={14} className={styles.azure} /> Travel Window
              </span>
              <input type="date" />
            </label>

            <label className={styles.field}>
              <span className={styles.label}>
                <Icon name="bed" size={14} /> Rooms Needed
              </span>
              <span className={styles.selectWrap}>
                <select value={rooms} onChange={(e) => setRooms(e.target.value)}>
                  <option value="1">1 Room (Private)</option>
                  <option value="2">2 Rooms</option>
                  <option value="3">3 Rooms</option>
                  <option value="4">4 Rooms</option>
                  <option value="5">5 Rooms</option>
                  <option value="6-10">6 - 10 Rooms</option>
                  <option value="10+">10+ Rooms (Group Tier)</option>
                </select>
                <Icon name="expand_more" size={18} />
              </span>
            </label>

            <label className={styles.field}>
              <span className={styles.label}>
                <Icon name="groups" size={14} /> Travelers
              </span>
              <span className={styles.selectWrap}>
                <select value={travelers} onChange={(e) => setTravelers(e.target.value)}>
                  <option value="1">1 Traveler</option>
                  <option value="2">2 Travelers</option>
                  <option value="3-4">3 - 4 Travelers</option>
                  <option value="5-8">5 - 8 Travelers</option>
                  <option value="9-12">9 - 12 Travelers</option>
                  <option value="12+">12+ Travelers (Delegation)</option>
                </select>
                <Icon name="expand_more" size={18} />
              </span>
            </label>

            <button type="submit" className={`btn btn--gold ${styles.submit}`}>
              <Icon name="travel_explore" size={18} />
              Find Itineraries
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
