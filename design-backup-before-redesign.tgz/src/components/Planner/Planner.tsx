"use client";

import { useEffect, useState } from "react";
import Icon from "@/components/Icon/Icon";
import { contact, tours } from "@/data/site";
import styles from "./Planner.module.scss";

const tourOptions = [
  ...tours.map((t) => ({ value: t.id, label: `${t.title} (${t.duration.replace(/\s/g, "")})` })),
  { value: "custom", label: "Fully Customized Multi-Country Route" },
];

const counts = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "10+"];

function makeCode() {
  return `LM-${Math.floor(100 + Math.random() * 900)}`;
}

type Status = "idle" | "sending" | "sent" | "error";

export default function Planner() {
  const [mode, setMode] = useState<"fit" | "group">("fit");
  const [tour, setTour] = useState(tourOptions[0].value);
  const [rooms, setRooms] = useState("1");
  const [persons, setPersons] = useState("2");
  const [code, setCode] = useState("LM-000");
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState("");

  useEffect(() => {
    setCode(makeCode());
    // Preselect a tour when arriving from a "View Details" / "Book Package" link
    const fromUrl = new URLSearchParams(window.location.search).get("tour");
    if (fromUrl && tourOptions.some((o) => o.value === fromUrl)) setTour(fromUrl);
  }, []);

  function switchMode(next: "fit" | "group") {
    setMode(next);
    if (next === "fit") {
      setRooms("1");
      setPersons("2");
    } else {
      setRooms("10+");
      setPersons("10+");
    }
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const form = new FormData(e.currentTarget);

    if (String(form.get("captcha")).trim().toUpperCase() !== code) {
      setError("The security code doesn't match. Please try again.");
      setCode(makeCode());
      return;
    }

    setStatus("sending");
    const payload = Object.fromEntries(form.entries());
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: mode, ...payload }),
      });
      if (!res.ok) throw new Error((await res.json()).error ?? "Something went wrong");
      setStatus("sent");
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  return (
    <section className={styles.section} id="planner">
      <div className="container">
        <div className={styles.panel}>
          {/* Left: concierge info */}
          <div className={styles.aside}>
            <div className={styles.glow} aria-hidden="true" />
            <div className={styles.asideBody}>
              <span className={styles.eyebrow}>Dedicated Travel Advisory</span>
              <h3 className={styles.asideTitle}>Get In Touch With Our Travel Specialists</h3>
              <p className={styles.asideText}>
                Whether you are planning a private bespoke expedition for family, a high-touch honeymoon, or
                managing corporate group movements across the Americas, our executive desk is at your service.
              </p>

              <div className={styles.specialist}>
                <div className={styles.specialistHead}>
                  <span className={styles.avatar}>TG</span>
                  <div>
                    <div className={styles.specialistName}>Tushar &amp; Shobhit Goyal</div>
                    <div className={styles.specialistRole}>Senior Destination Directors • Americas Desk</div>
                  </div>
                </div>
                <p className={styles.specialistQuote}>
                  “Supporting co-ordination at graveyard timings with clockwork precision for every single guest.”
                </p>
              </div>

              <div className={styles.contacts}>
                <a href={`tel:${contact.usaTel}`}>
                  <Icon name="phone_in_talk" className={styles.gold} />
                  <span>
                    USA Concierge: <strong>{contact.usaPhone}</strong>
                  </span>
                </a>
                <a href={`tel:${contact.indiaTel}`}>
                  <Icon name="call" className={styles.azure} />
                  <span>
                    India Direct: <strong>{contact.indiaPhone} / {contact.indiaAltPhone}</strong>
                  </span>
                </a>
                <a href={`mailto:${contact.inquiryEmail}`}>
                  <Icon name="mail" className={styles.gold} />
                  <span>
                    Inquiries: <strong>{contact.inquiryEmail}</strong>
                  </span>
                </a>
              </div>
            </div>

            <div className={styles.asideFoot}>
              <span>
                <span className={styles.dot} /> Response in 4 Hours
              </span>
              <span>•</span>
              <span>100% Customized Pacing</span>
            </div>
          </div>

          {/* Right: form */}
          <div className={styles.formWrap}>
            {status === "sent" ? (
              <div className={styles.success}>
                <Icon name="check_circle" size={48} />
                <h3>Thank you — your query is in.</h3>
                <p>
                  One of our travel specialists will send your personalized proposal by email and WhatsApp,
                  usually within 4 hours.
                </p>
                <button type="button" className="btn btn--navy" onClick={() => setStatus("idle")}>
                  Send another query
                </button>
              </div>
            ) : (
              <>
                <div className={styles.toggle} role="tablist">
                  <button
                    type="button"
                    role="tab"
                    aria-selected={mode === "fit"}
                    className={mode === "fit" ? styles.toggleActive : ""}
                    onClick={() => switchMode("fit")}
                  >
                    <Icon name="person" size={18} className={styles.azure} />
                    FIT Query (Individual)
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={mode === "group"}
                    className={mode === "group" ? styles.toggleActive : ""}
                    onClick={() => switchMode("group")}
                  >
                    <Icon name="groups" size={18} className={styles.gold} />
                    Group Query
                  </button>
                </div>

                <form className={styles.form} onSubmit={onSubmit}>
                  <div className={styles.row}>
                    <label className={styles.field}>
                      <span className={styles.label}>Destination / Tour Preference</span>
                      <span className={styles.selectWrap}>
                        <select name="tour" value={tour} onChange={(e) => setTour(e.target.value)}>
                          {tourOptions.map((o) => (
                            <option key={o.value} value={o.value}>
                              {o.label}
                            </option>
                          ))}
                        </select>
                        <Icon name="expand_more" size={18} />
                      </span>
                    </label>
                    <label className={styles.field}>
                      <span className={styles.label}>Preferred Travel Date</span>
                      <input name="travelDate" type="date" />
                    </label>
                  </div>

                  <div className={styles.row}>
                    <label className={styles.field}>
                      <span className={styles.label}>
                        No. of Rooms <small>select 1 to 10+</small>
                      </span>
                      <span className={styles.selectWrap}>
                        <select name="rooms" value={rooms} onChange={(e) => setRooms(e.target.value)}>
                          {counts.map((c) => (
                            <option key={c} value={c}>
                              {c} {c === "1" ? "Room" : "Rooms"}
                            </option>
                          ))}
                        </select>
                        <Icon name="expand_more" size={18} />
                      </span>
                    </label>
                    <label className={styles.field}>
                      <span className={styles.label}>
                        No. of Persons <small>select 1 to 10+</small>
                      </span>
                      <span className={styles.selectWrap}>
                        <select name="persons" value={persons} onChange={(e) => setPersons(e.target.value)}>
                          {counts.map((c) => (
                            <option key={c} value={c}>
                              {c} {c === "1" ? "Person" : "Persons"}
                            </option>
                          ))}
                        </select>
                        <Icon name="expand_more" size={18} />
                      </span>
                    </label>
                  </div>

                  <div className={styles.row}>
                    <label className={styles.field}>
                      <span className={styles.label}>Your Name / Agency</span>
                      <input name="name" type="text" required placeholder="e.g. Arundeep Kaur / Traviam Holidays" />
                    </label>
                    <label className={styles.field}>
                      <span className={styles.label}>Email Address</span>
                      <input name="email" type="email" required placeholder="yourname@domain.com" />
                    </label>
                  </div>

                  <div className={styles.row}>
                    <label className={styles.field}>
                      <span className={styles.label}>Contact / WhatsApp Number</span>
                      <input name="phone" type="tel" required placeholder="+1 / +91 / +44 phone" />
                    </label>
                    <label className={styles.field}>
                      <span className={styles.label}>
                        Security Verification <small>Spam protection</small>
                      </span>
                      <span className={styles.captcha}>
                        <span className={styles.code} aria-label={`Security code ${code}`}>
                          {code}
                        </span>
                        <input name="captcha" type="text" required placeholder="Enter code" autoComplete="off" />
                      </span>
                    </label>
                  </div>

                  {/* Honeypot: hidden from people, bots tend to fill it */}
                  <input type="text" name="website" tabIndex={-1} autoComplete="off" className={styles.honeypot} />

                  <label className={styles.field}>
                    <span className={styles.label}>Special Preferences &amp; Requirements (Optional)</span>
                    <textarea
                      name="notes"
                      rows={3}
                      placeholder="Specify hotel category (4★ / 5★), private guide language, flight inclusions, or custom cities..."
                    />
                  </label>

                  {error && (
                    <p className={styles.error} role="alert">
                      <Icon name="error" size={16} /> {error}
                    </p>
                  )}

                  <div className={styles.submitRow}>
                    <label className={styles.consent}>
                      <input type="checkbox" name="consent" defaultChecked required />
                      I agree to receive the personalized proposal via Email &amp; WhatsApp.
                    </label>
                    <button type="submit" className="btn btn--gold" disabled={status === "sending"}>
                      <Icon name="send" size={18} />
                      {status === "sending" ? "Sending…" : "Submit Query Now"}
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
