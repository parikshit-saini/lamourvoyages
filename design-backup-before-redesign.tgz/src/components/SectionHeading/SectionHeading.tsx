import Icon from "@/components/Icon/Icon";
import styles from "./SectionHeading.module.scss";

type Props = {
  eyebrow: string;
  title: string;
  text?: string;
  align?: "left" | "center";
  eyebrowIcon?: string;
  theme?: "light" | "dark";
};

export default function SectionHeading({ eyebrow, title, text, align = "center", eyebrowIcon, theme = "light" }: Props) {
  return (
    <div className={`${styles.heading} ${styles[align]} ${styles[theme]}`}>
      <span className={styles.eyebrow}>
        {eyebrowIcon ? <Icon name={eyebrowIcon} size={16} /> : align === "left" && <span className={styles.rule} />}
        {eyebrow}
      </span>
      <h2 className={styles.title}>{title}</h2>
      {align === "center" && <div className={styles.bar} />}
      {text && <p className={styles.text}>{text}</p>}
    </div>
  );
}
