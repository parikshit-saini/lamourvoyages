import Icon from "@/components/Icon/Icon";
import SectionHeading from "@/components/SectionHeading/SectionHeading";
import { contact, testimonials } from "@/data/site";
import styles from "./Testimonials.module.scss";

function initials(name: string) {
  return name
    .replace(/^Mr\.?\s+/i, "")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

// Bold brand / people names inside a quote
function highlight(text: string) {
  const parts = text.split(/(L'amour Voyages|Shobhit Goyal's Lamour Voyages USA LLC|Happy customer|Tushar)/g);
  return parts.map((p, i) => (i % 2 === 1 ? <strong key={i}>{p}</strong> : p));
}

export default function Testimonials() {
  return (
    <section className={styles.section} id="reviews">
      <div className="container">
        <SectionHeading
          eyebrow="Verified Trade Partner Feedback"
          eyebrowIcon="reviews"
          title="What Our Clients Tell About Us"
          text="Honored endorsements from leading tour operators, corporate coordinators, and travel leaders worldwide."
        />

        <div className={styles.grid}>
          {testimonials.map((t, i) => (
            <figure key={t.name} className={styles.card}>
              <div>
                <div className={styles.stars} aria-label="5 out of 5 stars">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Icon key={s} name="star" size={18} filled />
                  ))}
                </div>
                <blockquote className={styles.quote}>“{highlight(t.quote)}”</blockquote>
              </div>
              <figcaption className={styles.author}>
                <span className={`${styles.avatar} ${i % 2 ? styles.avatarGold : ""}`}>{initials(t.name)}</span>
                <span>
                  <span className={styles.name}>{t.name}</span>
                  <span className={styles.role}>{t.role}</span>
                </span>
              </figcaption>
            </figure>
          ))}

          <div className={styles.callout}>
            <div>
              <span className={styles.calloutEyebrow}>Partner With Us</span>
              <h3>B2B Trade Alliances</h3>
              <p>
                We provide wholesale ground handling, group allocations, and customized white-label luxury
                itineraries for certified travel advisors globally.
              </p>
            </div>
            <a href={`tel:${contact.usaTel}`} className="btn btn--azure" style={{ width: "100%" }}>
              <Icon name="support_agent" size={18} /> Speak to Trade Desk
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
