import Image from "next/image";
import Link from "next/link";
import Icon from "@/components/Icon/Icon";
import type { Tour } from "@/data/site";
import styles from "./Tours.module.scss";

type Props = {
  tour: Tour;
  ctaLabel?: string;
  showFavorite?: boolean;
};

export default function TourCard({ tour, ctaLabel = "View Details", showFavorite = false }: Props) {
  const href = `/contact-us?tour=${encodeURIComponent(tour.id)}#planner`;

  return (
    <article className={styles.card}>
      <div className={styles.media}>
        <Image
          src={tour.image}
          alt={tour.title}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 768px) 50vw, 100vw"
          className={styles.image}
        />
        <div className={styles.shade} />
        <span className={styles.duration}>{tour.duration}</span>
        {showFavorite && (
          <span className={styles.favorite} aria-hidden="true">
            <Icon name="favorite_border" size={18} />
          </span>
        )}
        <span className={styles.badge}>
          <Icon name={tour.badge.icon} size={14} /> {tour.badge.label}
        </span>
      </div>

      <div className={styles.body}>
        <div>
          <h3 className={styles.title}>{tour.title}</h3>
          <p className={styles.desc}>{tour.description}</p>
          <div className={styles.tags}>
            {tour.tags.map((t) => (
              <span key={t.label} className={`${styles.tag} ${t.tone ? styles[t.tone] : ""}`}>
                {t.label}
              </span>
            ))}
          </div>
        </div>

        <div className={styles.footer}>
          <div>
            <span className={styles.quoteLabel}>Custom Quote</span>
            <span className={styles.quoteValue}>Curated Inquiry</span>
          </div>
          <Link href={href} className="btn btn--navy btn--sm">
            {ctaLabel}
            <Icon name="arrow_outward" size={14} />
          </Link>
        </div>
      </div>
    </article>
  );
}
