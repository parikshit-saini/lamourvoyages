"use client";

import { useMemo, useState } from "react";
import { tourFilters, tours } from "@/data/site";
import TourCard from "./TourCard";
import styles from "./Tours.module.scss";

export default function TourPortfolio() {
  const [active, setActive] = useState(0);

  const visible = useMemo(() => {
    const regions = tourFilters[active].regions;
    // "All Tours" shows the extended portfolio (the signature tours are featured above)
    if (!regions) return tours.filter((t) => !t.featured);
    return tours.filter((t) => t.regions.some((r) => regions.includes(r)));
  }, [active]);

  return (
    <>
      <div className={styles.filters} role="tablist" aria-label="Filter tours">
        {tourFilters.map((f, i) => (
          <button
            key={f.label}
            type="button"
            role="tab"
            aria-selected={active === i}
            className={`${styles.filter} ${active === i ? styles.filterActive : ""}`}
            onClick={() => setActive(i)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className={styles.grid}>
        {visible.map((tour) => (
          <TourCard key={tour.id} tour={tour} ctaLabel="Book Package" />
        ))}
      </div>
    </>
  );
}
