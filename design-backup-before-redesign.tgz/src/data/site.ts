// ---------------------------------------------------------------
// Central content for the site. Edit here, and every page updates.
// ---------------------------------------------------------------

export const LOGO_URL = "https://lamourvoyages.com/wp-content/uploads/2019/11/logo-lamour-1.png";

export const images = {
  hero: "https://lh3.googleusercontent.com/aida/ALJJyrCEF6Tgi6LxyWp6Y_z_M4U816vSk10E4uSo6IYAX0uYDep3i-yj3vOfAxkpSfy2B0af9Rka3dmpJIdm1dvK5-fRroI2BuYozTjJEpe7GfaUynJMw8ppQHv4fGneaf79t1lsliP0QF4_fIig7zizRs0O4tMHlVSYDN48KeSqPDtUy4JMrGpUm4FHf1tng5fc_XgTTh1F-5Bk12lwQtZhuVA2ojgnFKh1eAkhEw0NLBPcVw",
  brazil: "https://lh3.googleusercontent.com/aida/ALJJyrAs1U4c_pS9Eq_e-3yVhMQoCYWl_v-4tsep92JdhnNV7fMSO1qJ2Vro746VC1siS-3iSSzm9f9LL3i-iUWeGnQwYYo3yyPg3k1MJdkcwlKsFdwKwnVXnftilmEu-LqztCNULHI_Lpa7QUPb-WiPp8YBmC_SM2AJ_o9GksMYwOGfVouyF8KVsYfU3GTEU46hI2E3alL5F8AWngXZ4HROU5hB0G9Vg25JduH7W7YtEGOrGA",
  brazilArgentina: "https://lh3.googleusercontent.com/aida/ALJJyrAAPiW8qUdG7eqCLCcz5KLOFblAOtf_d6UM54jqANJ3UGhDr-_222hvSLwcqOpzrB_d4bm7qeC90ZOrjWDFVWgglh_pFCI-QdbI9ib_3-rDM8HqHpaCRl3MsmkCN3AfJ0CLJLhM-Ikk8rBzBNTns8NhvMjcyYkAjhMU9zAJJBRyxcwK7XSx1nbegsWh-HYLcLS8ZXv9Y2GjJ-xcRslvL5qpzny-WK00cFBUItYXnDftyg",
  newYork: "https://lh3.googleusercontent.com/aida/ALJJyrBlmL_oZbT-ACRa1bny5uAFZ-pnpOmvINH96Lh0k7MPgTR_9OvZfOn87NIFDAgc3l-VE9VdRPwV59o_SxFADF4y9lZ5qG9DJFJyZlHw7GjCZYSmkZgDtLHUHdQ0A1IjAkRGDmyftmkEUkBruFyojtc_0b7wB5ijots_qyE-d7OLW9CxsHT1nWyvHcXVeGh9G8W0WYCmOjBmTflqp7MqT6eOftobK2RMo0XvBoBYPkj5YA",
  eastAmerica: "https://lh3.googleusercontent.com/aida/ALJJyrD6-kgxJexiN3E8dLiD7neMKYyol3OBw0v4NafghDMWYJiiVFdK5l49JnUN8lQI-41-AYm4kZCYZ9MUBw08uOkAe6Ol20ohrxzWTfiFAraymWBU1FfNHgUBHwXS9oHRaJYjMrEp69ujqrOe3nTqv7LOFWcBA_DLfHSaoaaOSa2_4OJObT794sMaMhQJbjtmVLHOnPYTAPdgMaO2eWAKkW3S7YWvxVBpjsbeoemot3QRZw",
  westCoast: "https://lh3.googleusercontent.com/aida/ALJJyrCVa6tC86FaSADeipAwunZEEgAMunNkQgDeUoMzWcxUUk2V4eiNzP8fr6H7O-LBFhaM8kRUyQyLFEbMQiWX7YypN2S_dY9VdvE5Dg6oZDN4jKaDJpPLB4yIAOWdRo1S5cFrD9-o7uLzvyZkxshkgzfBArWg3AtK0t55xar3v8QaNxFTio3OOiyMCxNgMyi-yuVksC0x56c8BgPVdvM5AQaxGjmX4_9nCVkjQcxgZNNDDQ",
  canada: "https://lh3.googleusercontent.com/aida-public/AB6AXuD4i0I3MvnI0W54AIvq44xyhgSzanhGPhZaU9uUuDqNOOE2UlHG1BweziEdEE0fEoJMf_p_VMqNEJrNuK5Ko91E2O85TwAQIyLu5UljxouQoPEvaNy5EPcF4ndjEyqqJ7e9YEPYt0Jit7knWCd-PZ1XPeoa5h9sb8k7o4x6MPhjPcvEuvttG_kk1O7e1Wg8oJN1lvWMBP7Yn_-zP9B7pTZymbrfdaualjgN7YCLu0-F",
  miami: "https://lh3.googleusercontent.com/aida-public/AB6AXuBmwhBDuwmZZ1MJ5fdy_xBDv8L2dg4d7ob4Ym-kMo1kgejMAXKu-PgOmqLIj4s-Ca4eATxK78FfntKyDVafm7TfpQ_ns_9sNb3d9Li-iwDNMPktb7qLDwXxXdaQto8gKz-thzW-fTrKQgDWQbxYman3W1PGxGYYQ-YF9aDcwdHTz8SqhxYLaOF3NHDh1B5jQfRfRg58_OpTWz0YnpE-kPVmsQZTlbINE2_Mhn-FKI4n",
  boston: "https://lh3.googleusercontent.com/aida-public/AB6AXuAdFHVjqTne9N29Cc9I5Bkx89I4jFsu72rtC5SwzWCOW9VlGEY6WCunq_6HQZAqpJqZeiKM9LHYyrQGJQZ58VQbKEbStgHtHlggJKUvTbxH3tNfJRM4WT89ZjH0pzT_yn17DU7uzljO5LxcJguWkf0Xe3OjkQpflxUgIWqb9gztJVoSNNj0OkzQIJX7afFNtv-luXWvSMl8Xuk1O6YuLppImlU7dXmG_Ve4gbqsGDcN",
};

export const contact = {
  usaPhone: "+1 347 653 9583",
  usaTel: "+13476539583",
  indiaPhone: "+91 8130957237",
  indiaTel: "+918130957237",
  indiaAltPhone: "+91 9833442545",
  inquiryEmail: "md@lamourvoyages.com",
  conciergeEmail: "concierge@lamourvoyages.com",
};

export const offices = [
  { country: "United States", address: "Elizabeth, New Jersey, USA" },
  { country: "India", address: "Sector 62, Noida, NCR, India" },
  { country: "United Kingdom", address: "Harrow, Middlesex, London, UK" },
  { country: "Canada", address: "Fonthill, Ontario, Canada" },
];

export const social = [
  { label: "Facebook", href: "https://www.facebook.com/LAMOURUSA/", icon: "share" },
  { label: "Twitter", href: "https://twitter.com/LamourVoyages", icon: "public" },
  { label: "LinkedIn", href: "https://www.linkedin.com/in/lamour-voyages-936792164/", icon: "hub" },
  { label: "Instagram", href: "https://www.instagram.com/voyageslamour/", icon: "photo_camera" },
];

// ---------- Navigation (same structure/slugs as the live site) ----------
export type NavItem = { label: string; href: string; children?: NavItem[] };

export const trendingCities: NavItem[] = [
  { label: "New York", href: "/new-york" },
  { label: "Los Angeles", href: "/los-angeles" },
  { label: "Miami", href: "/miami" },
  { label: "Orlando", href: "/orlando" },
  { label: "Boston", href: "/boston" },
];

export const mainNav: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about-us" },
  { label: "Services", href: "/services" },
  { label: "North America", href: "/north-america" },
  { label: "South America", href: "/south-america" },
  { label: "Canada", href: "/canada" },
  { label: "Trending", href: "/trending-destination", children: trendingCities },
  { label: "Client Reviews", href: "/#reviews" },
  { label: "Contact", href: "/contact-us" },
];

// ---------- Tours ----------
export type Region = "east" | "west" | "south" | "canada" | "trending";

export type Tour = {
  id: string;
  title: string;
  duration: string;
  badge: { icon: string; label: string };
  description: string;
  tags: { label: string; tone?: "azure" | "gold" }[];
  image: string;
  regions: Region[];
  featured?: boolean;
};

export const tours: Tour[] = [
  {
    id: "most-happening-brazil",
    title: "Most Happening Brazil",
    duration: "8 N / 9 D",
    badge: { icon: "flag", label: "South America Highlights" },
    description:
      "Tour starts from Rio de Janeiro, Copacabana sands, Corcovado, Sugarloaf, vibrant samba culture & iconic landmarks.",
    tags: [{ label: "Private Flight" }, { label: "5-Star Belmond" }, { label: "VIP Chauffeur" }],
    image: images.brazil,
    regions: ["south"],
    featured: true,
  },
  {
    id: "sensational-brazil-argentina",
    title: "Sensational Brazil & Argentina",
    duration: "8 N / 9 D",
    badge: { icon: "public", label: "Two-Country Odyssey" },
    description:
      "Rio de Janeiro wonders through thunderous Iguazu Falls to passionate Buenos Aires tango parlors & fine wine cellars.",
    tags: [{ label: "Bespoke Route", tone: "azure" }, { label: "Tango Gala" }, { label: "Iguazu Helo" }],
    image: images.brazilArgentina,
    regions: ["south"],
    featured: true,
  },
  {
    id: "amazing-new-york",
    title: "Amazing New York",
    duration: "3 N / 4 D",
    badge: { icon: "apartment", label: "Manhattan Elite" },
    description:
      "Exclusive Tour of USA begins at the epicenter of commerce, Broadway VIP private boxes, helicopter city lights & Fifth Ave shopping.",
    tags: [{ label: "Manhattan Suites", tone: "gold" }, { label: "Broadway VIP" }, { label: "Statue Cruises" }],
    image: images.newYork,
    regions: ["east", "trending"],
    featured: true,
  },
  {
    id: "enchanting-east-america",
    title: "Enchanting East America",
    duration: "9 N / 10 D",
    badge: { icon: "account_balance", label: "Capital & Nature" },
    description:
      "The exclusive USA route traversing New York City, historic Philadelphia, Washington D.C. private monuments & thunderous Niagara Falls.",
    tags: [{ label: "Niagara Jetboat" }, { label: "Smithsonian VIP" }, { label: "Private Coach" }],
    image: images.eastAmerica,
    regions: ["east"],
    featured: true,
  },
  {
    id: "west-coast-delight",
    title: "West Coast Delight",
    duration: "7 N / 8 D",
    badge: { icon: "terrain", label: "Canyon & Pacific Coast" },
    description:
      "The exclusive Tour of USA starts from the Hollywood Walk of Fame, Los Angeles, Beverly Hills, sparkling Las Vegas Strip, and Grand Canyon rim.",
    tags: [{ label: "Canyon Helicopter" }, { label: "Vegas Bellagio" }, { label: "LA Private Tour" }],
    image: images.westCoast,
    regions: ["west", "trending"],
  },
  {
    id: "canadian-rockies-toronto",
    title: "Canadian Rockies & Toronto",
    duration: "8 N / 9 D",
    badge: { icon: "landscape", label: "Canada Prestige" },
    description:
      "Toronto CN Tower fine dining, roaring Niagara Falls, seamless flight to Calgary, Banff luxury alpine lodges and emerald glacial lakes.",
    tags: [{ label: "Rocky Mountaineer" }, { label: "Fairmont Stays" }, { label: "Private Concierge" }],
    image: images.canada,
    regions: ["canada"],
  },
  {
    id: "florida-sun-miami-orlando",
    title: "Florida Sun: Miami & Orlando",
    duration: "6 N / 7 D",
    badge: { icon: "wb_sunny", label: "Sun & Entertainment" },
    description:
      "Miami South Beach VIP yacht charters and nightlife seamlessly merged with Orlando theme park private VIP tour guides and luxury resort villas.",
    tags: [{ label: "Private Yacht" }, { label: "VIP Theme Park" }, { label: "Four Seasons" }],
    image: images.miami,
    regions: ["east", "trending"],
  },
  {
    id: "historic-boston-harvard",
    title: "Historic Boston & Harvard",
    duration: "5 N / 6 D",
    badge: { icon: "school", label: "Heritage & Coastal Charm" },
    description:
      "Walk the Freedom Trail with private historian escorts, Harvard & MIT academic private walk, and seaside Cape Cod coastal lobster dining.",
    tags: [{ label: "Historian Escort" }, { label: "Harvard Tour" }, { label: "Ritz-Carlton" }],
    image: images.boston,
    regions: ["east", "trending"],
  },
];

export const tourFilters: { label: string; regions: Region[] | null }[] = [
  { label: "All Tours", regions: null },
  { label: "USA East Coast", regions: ["east"] },
  { label: "USA West Coast", regions: ["west"] },
  { label: "South America & Brazil", regions: ["south"] },
  { label: "Canada & Trending Metropolises", regions: ["canada", "trending"] },
];

export const plannerTourOptions = [
  ...tours.map((t) => `${t.title} (${t.duration.replace(/\s/g, "")})`),
  "Fully Customized Multi-Country Route",
];

// ---------- Testimonials (from the current site) ----------
export const testimonials = [
  {
    quote:
      "Thanks a lot for all your Support during USA Trip, All the arrangements and transfers worked like clockwork, I appreciate your efforts in making this happen. I would highly recommend L'amour Voyages.",
    name: "Arundeep Kaur",
    role: "Travel Agent & Tour Operators • Traviam Holidays",
  },
  {
    quote:
      "Thanks for giving good services to my client. She is back and happy. I have added Happy customer in my kitty. Tushar was really very helpful and supporting our co-ordination at graveyard timings were too good.",
    name: "Komal Bijlani",
    role: "AVP Products & Operations • Travee Sdn Bhd",
  },
  {
    quote:
      "We are all checked in to leave. Had a great trip.. all your arrangements were very good. Thanks for all your efforts and coordination in ensuring the trip was seamless. A big thanks to Tushar who made it good.",
    name: "Meenakshi Dahake",
    role: "Vice President • Trail Blazer Tours India Pvt. Ltd.",
  },
  {
    quote:
      "We U-Tourizmo SPL strongly recommend working with Shobhit Goyal's Lamour Voyages USA LLC for services in Europe and USA. We have worked extensively with them and cannot be happier with any other company.",
    name: "Mr. Sumit Berry",
    role: "Director • U Tourismo SPL",
  },
  {
    quote:
      "Just want to say Thank you, as we are getting good feedback from our guest as we want. Anyways again thanks for all your support and hope the same continues in upcoming queries also.",
    name: "Shakshi Jain",
    role: "Travel Agent & Tour Operators • Zenith Leisure Holidays",
  },
];

export const hotelPartners = [
  { name: "Marriott", sub: "Hotels & Resorts", icon: "hotel" },
  { name: "Radisson Blu", icon: "stars" },
  { name: "Park Plaza", sub: "Victoria Amsterdam", icon: "location_city" },
  { name: "Mercure", sub: "Hotels" },
  { name: "Elite World", sub: "Hotels", icon: "diamond" },
];

// NOTE: verify these accreditations before launch — they came from the design mock.
export const affiliations = [
  { title: "Virtuoso Preferred", sub: "Global Luxury Travel Network", icon: "stars", tone: "gold" },
  { title: "Four Seasons Preferred", sub: "Exclusive Partner Privileges", icon: "hotel_class", tone: "azure" },
  { title: "IATA & ASTA Certified", sub: "Accredited Agency Worldwide", icon: "verified_user", tone: "gold" },
] as const;

export const whyBook = [
  {
    icon: "schedule",
    tone: "gold",
    title: "24x7 Global Availability",
    text: "True round-the-clock coordination with active offices across USA, UK, India, and Canada time zones ensuring frictionless operations.",
  },
  {
    icon: "tune",
    tone: "azure",
    title: "Tailor-Made by Specialists",
    text: "Every detail is shaped by experienced travel curators who know each neighborhood, hotel wing, and exclusive entrance personally.",
  },
  {
    icon: "verified_user",
    tone: "gold",
    title: "Transparent B2B & B2C Delivery",
    text: "Trusted by leading global agencies, corporate delegations, and discerning private families with zero hidden costs or service gaps.",
  },
] as const;
